
#include <p24Fxxxx.h>

// FBS
#pragma config BWRP = OFF               // Table Write Protect Boot (Boot segment may be written)
#pragma config BSS = OFF                // Boot segment Protect (No boot program Flash segment)

// FGS
#pragma config GWRP = OFF               // General Segment Code Flash Write Protection bit (General segment may be written)
#pragma config GCP = OFF                // General Segment Code Flash Code Protection bit (No protection)

// FOSCSEL
#pragma config FNOSC = FRC              // Oscillator Select (Fast RC oscillator (FRC))
#pragma config IESO = OFF               // Internal External Switch Over bit (Internal External Switchover mode disabled (Two-Speed Start-up disabled))

// FOSC
#pragma config POSCMOD = NONE           // Primary Oscillator Configuration bits (Primary oscillator disabled)
#pragma config OSCIOFNC = ON            // CLKO Enable Configuration bit (CLKO output disabled; pin functions as port I/O)
#pragma config POSCFREQ = HS            // Primary Oscillator Frequency Range Configuration bits (Primary oscillator/external clock input frequency greater than 8 MHz)
#pragma config SOSCSEL = SOSCLP         // SOSC Power Selection Configuration bits (Secondary oscillator configured for low-power operation)
#pragma config FCKSM = CSDCMD           // Clock Switching and Monitor Selection (Both Clock Switching and Fail-safe Clock Monitor are disabled)

// FWDT
#pragma config WDTPS = PS32768          // Watchdog Timer Postscale Select bits (1:32,768)
#pragma config FWPSA = PR128            // WDT Prescaler (WDT prescaler ratio of 1:128)
#pragma config WINDIS = OFF             // Windowed Watchdog Timer Disable bit (Standard WDT selected; windowed WDT disabled)
#pragma config FWDTEN = OFF             // Watchdog Timer Enable bit (WDT disabled (control is placed on the SWDTEN bit))

// FPOR
#pragma config BOREN = BOR3             // Brown-out Reset Enable bits (Brown-out Reset enabled in hardware; SBOREN bit disabled)
#pragma config PWRTEN = ON              // Power-up Timer Enable bit (PWRT enabled)
#pragma config I2C1SEL = PRI            // Alternate I2C1 Pin Mapping bit (Default location for SCL1/SDA1 pins)
#pragma config BORV = V18               // Brown-out Reset Voltage bits (Brown-out Reset set to lowest voltage (1.8V))
#pragma config MCLRE = ON               // MCLR Pin Enable bit (MCLR pin enabled; RA5 input pin disabled)

// FICD
#pragma config ICS = PGx1               // ICD Pin Placement Select bits (PGC1/PGD1 are used for programming and debugging the device)

// FDS
#pragma config DSWDTPS = DSWDTPSF       // Deep Sleep Watchdog Timer Postscale Select bits (1:2,147,483,648 (25.7 Days))
#pragma config DSWDTOSC = SOSC          // DSWDT Reference Clock Select bit (DSWDT uses SOSC as reference clock)
#pragma config RTCOSC = SOSC            // RTCC Reference Clock Select bit (RTCC uses SOSC as reference clock)
#pragma config DSBOREN = ON             // Deep Sleep Zero-Power BOR Enable bit (Deep Sleep BOR enabled in Deep Sleep)
#pragma config DSWDTEN = OFF            // Deep Sleep Watchdog Timer Enable bit (DSWDT disabled)




//#include "GenericTypeDefs.h"
#include "include\define.h"
#include "i2c.h"
#include <string.h>
#include "PwrMgnt.h"
//#include "Console.h"
//#include "ports.h"
#include "Rtcc.h"


int key;

// rf input/output buffers:
extern char RxPacket[]; // Receive data puffer (payload only)
extern char TxPacket[]; // Transmit data puffer
extern unsigned char RxPacketLen;
extern BOOL hasPacket;
extern WORD rcrc, ccrc;
BOOL kuld;
unsigned char mp;

// Set Date/Time Variables

SHORT currentControlSet;
BYTE daysPerMonth[12] = {31, 28, 31, 30, 31, 30,
    31, 31, 30, 31, 30, 31};
XCHAR monthNames[12][3] = {
    { 'J', 'a', 'n',},
    { 'F', 'e', 'b',},
    { 'M', 'a', 'r',},
    { 'A', 'p', 'r',},
    { 'M', 'a', 'y',},
    { 'J', 'u', 'n',},
    { 'J', 'u', 'l',},
    { 'A', 'u', 'g',},
    { 'S', 'e', 'p',},
    { 'O', 'c', 't',},
    { 'N', 'o', 'v',},
    { 'D', 'e', 'c'}
};
//Function Prototypes
void user_main(void);
void USER_Function(void);
void RTCC_configure(void);

///////////////////////////////// FONTS ///////////////////////////////////////
extern const FONT_FLASH Font29pix; //GenBasB_1;
extern const FONT_FLASH Font53pix; //GenBasB_2;
extern const FONT_FLASH Font13pix;

/************************************************************************
 Function: Int2Str(XCHAR *pStr, WORD value, SHORT charCount)
 ************************************************************************/
void Int2Str(XCHAR *pStr, WORD value, SHORT charCount) {
    pStr = pStr + (charCount - 1);

    // convert the value to string starting from the ones, then tens, then hundreds etc...
    do {
        *pStr-- = (value % 10) + '0';
        value /= 10;
    } while (charCount--);
}

//*************************************************************************************
//
//		Init
//
//*************************************************************************************

void init(void) {
    AD1PCFG = 0b1111111111111111; // AD port config register 1 -> port is dig. I/O; 0 -> analog input

    A0_TRIS_BIT = 0; //TRISAbits.TRISA3 (LCD A0)
    RST_TRIS_BIT = 0;
    RST_LAT_BIT = 0;
    CS_TRIS_BIT = 0;
    CS_LAT_BIT = 1;

    BUZZER = 0; //PIEZO
    BUZZER_TRIS = 0;

    LED = 0; //LED
    LED_TRIS = 0;

    HP03_XCLR = 0; //HP03 XCLR
    HP03_XCLR_TRIS = 0;

    // RF =====================
    TRISBbits.TRISB2 = 0; // NSEL        	PORTBbits.RB2                              // chip select, active low output
    TRISAbits.TRISA7 = 0; // NFFS        	PORTAbits.RA7                              // rx fifo select, active low output
    TRISAbits.TRISA6 = 1; // NIRQ			PORTAbits.RA6
    //LATAbits.LATA6=0;
    NSEL = 1; // nSEL inactive
    NFFS = 1; // nFFS inactive

    //PADCFG1bits.OC1TRIS=1; //RA6?

    CNPU1bits.CN12PUE = 1; //RB14	key input
    LATBbits.LATB0 = 1; //csak �gy m�k�dik a pullup-os bemenet...?

    CNEN1bits.CN12IE = 1;
    IFS1bits.CNIF = 0;
    IEC1bits.CNIE = 1;

    INTCON2bits.INT2EP = 1; // INT2 lefut� �l

    CNPD1 = 0; // pulldowns disable
    CNPD2 = 0; // pulldowns disable

    //================= SPI setup ======================================

    SPI1CON1 = 0b0000000100111111; // SMP:0, CKP:0, CKE:1, 8bit mode
    SPI1CON2 = 0b0000000000000000; //enhanced buffer mode disable
    SPI1STATbits.SPIEN = 1; /* Enable/Disable the spi module */

    /************************ IIC setup ****************************/

    /* clear the I2CEN bit */
    I2C1CONbits.I2CEN = 0;

    /* clear the SI2C & MI2C Interrupt enable bits */
    IEC1bits.SI2C1IE = 0;
    IEC1bits.MI2C1IE = 0;

    /* clear the SI2C & MI2C Interrupt flag bits */
    IFS1bits.SI2C1IF = 0;
    IFS1bits.MI2C1IF = 0;

    IEC3bits.RTCIE = 1;

    I2C1BRG = 200; //39
    I2C1CON = 0b1000001000000000; //I2C1 enabled, slew rate control disabled

    REFOCON = 0b0000011100000000; //Reference Oscillator Output disabled; ref osc divisor Base clock value divided by 128 (HP03 MCLK)
}

//*************************************************************************
//
// Int on change interrupt
//
//*************************************************************************

void __attribute__((interrupt, shadow, auto_psv)) _CNInterrupt(void) {
    key = 0;
    if (!PORTBbits.RB0) key += 1;
    if (!PORTBbits.RB1) key += 2;
    if (!PORTBbits.RB14) {
        key += 4;
        kuld = TRUE;
    }
    IFS1bits.CNIF = 0;
}

//*************************************************************************
//
// RTCC interrupt
//
//*************************************************************************

void __attribute__((interrupt, shadow, auto_psv)) _RTCCInterrupt(void) {
    IFS3bits.RTCIF = 0;
}

//************************************************************************
//
//	Main
//
//************************************************************************

int main(void)
 {
    int i;
    init();

    //ConsoleInit();			//initialize the console

    InitGraph(); // RESET-eli az RF modult is a k�z�s RESET vonalon kereszt�l!!!!!!!!!!!!!!!!!!!!!!!!
	//DelayMs(100);
   	RF_init();
    RTCCInit();
    RTCCProcessEvents();

    ClearDevice();

    TransferToLCD();

    TxPacket[0] = 0x33; //3
    TxPacket[1] = 0x2c; //,
    TxPacket[7] = 0x2c;
    TxPacket[12] = 0x2c;
    //			TxPacket[15] = 13;
    //			TxPacket[16] = 10;

    _date_str[22] = TxPacket[0];


    while (1) {
        
        key = 0;

        RTCCProcessEvents();

        SetFont((void *) &Font29pix); //29
        measure();

        SetFont((void *) &Font53pix); //53
        OutTextXY(6, -12, _time_str);

        SetFont((void *) &Font13pix);
        OutTextXY(5, 29, _date_str);

 		for (i = 0; i < 128; i++) {
        	PutPixel(i, 44); //44,42
        	PutPixel(i, 42);
    	}

       	TransferToLCD();
        
        TxPacket[2] = _time.hr; //_time_str[0];
        TxPacket[3] = _time.min; //_time_str[1];
        TxPacket[4] = _time.sec; //_time_str[2];
        //			TxPacket[5] = _time_str[3];
        //			TxPacket[6] = _time_str[4];

        mPWRMGNT_GotoSleepMode();

        if (PwrMgnt_WakeupSource() == WAKEUP_SLEEP) LED = 0;
        Tx(15);
        
    }
}

/****************************************************************************
  Function:
    WORD ProcessMessageTime( WORD translatedMsg, OBJ_HEADER* pObj, GOL_MSG* pMsg )

  Description:
    This function processes the messages for the time and date screen.  It
    allows the user to set the current time and date of the RTCC module.

  Precondition:
    Call ShowScreenTime() prior to using this function to display the correct
    screen.

  Parameters:
    WORD translatedMsg  - The translated control-level message
    OBJ_HEADER* pObj    - Object to which the message applies
    GOL_MSG* pMsg       - The original system message information

  Return Values:
    0   - Do not call the default message handler.
    1   - Call the default message handler.

  Remarks:
    None
 ***************************************************************************/

WORD ProcessMessageTime(void) {
    signed char change;
    WORD controlID;
    signed char day;
    signed char dayMax;
    signed char hour;
    signed char minute;
    signed char month;
    signed char year;

    /*
    //    controlID = GetObjID(pObj);
        switch (controlID)
        {
           case ID_RTCC_BUTTON_NEXT:
                // Show the old control set as unselected.
                IndicateFocus( BLACK );

                // Set the next control as active.
                currentControlSet ++;
                if (currentControlSet > CONTROL_SET_MAX)
                {
                    currentControlSet = 0;
                }
                // Show the new control set as selected.
                IndicateFocus( WHITE );

                return 0;   // Hidden button
                break;

           case ID_RTCC_BUTTON_PREVIOUS:
                // Show the old control set as unselected.
                IndicateFocus( BLACK );

                // Set the next control as active.
                currentControlSet --;
                if (currentControlSet < 0 )
                {
                    currentControlSet = CONTROL_SET_MAX;
                }

                // Show the new control set as selected.
                IndicateFocus( WHITE );

                return 0;   // Hidden button
                break;

            case ID_RTCC_BUTTON_HOME:
                screenState = SCREEN_DISPLAY_MAIN;
                return 0;   // Hidden button
                break;

            case ID_DAY_PLUS:
            case ID_MONTH_PLUS:
            case ID_YEAR_PLUS:
            case ID_HOUR_PLUS:
            case ID_MINUTE_PLUS:
                if (translatedMsg == BTN_MSG_PRESSED)
                {
                    change = +1;
                }
                else
                {
                    return 1;
                }
                break;

            case ID_DAY_MINUS:
            case ID_MONTH_MINUS:
            case ID_YEAR_MINUS:
            case ID_HOUR_MINUS:
            case ID_MINUTE_MINUS:
                if (translatedMsg == BTN_MSG_PRESSED)
                {
                    change = -1;
                }
                else
                {
                    return 1;
                }
                break;

            default:
                return 0;
        }
     */
    // Update the selected field.

    RTCCProcessEvents();
    hour = RTCCGetBinHour();
    minute = RTCCGetBinMin();
    day = RTCCGetBinDay();
    month = RTCCGetBinMonth();
    year = RTCCGetBinYear();

    dayMax = daysPerMonth[month - 1];

    // February has one day more for a leap year, unless it is on the thousands
    if ((month == 2) && ((year % 4) == 0) && (year != 0)) {
        dayMax++;
    }

    // Change the appropriate setting.  Allow the controls to roll over.
    switch (currentControlSet) {
        case 1://CONTROL_SET_DAY:
            day += change;
            if (day < 1) {
                day = dayMax;
            }
            if (day > dayMax) {
                day = 1;
            }
            break;

        case 2://CONTROL_SET_MONTH:
            month += change;
            if (month < 1) {
                month = 12;
            }
            if (month > 12) {
                month = 1;
            }
            break;

        case 3://CONTROL_SET_YEAR:
            year += change;
            if (year < 0) {
                year = 99;
            }
            if (year > 99) {
                year = 0;
            }
            break;

        case 4://CONTROL_SET_HOUR:
            hour += change;
            if (hour < 0) {
                hour = 23;
            }
            if (hour > 23) {
                hour = 0;
            }
            break;

        case 5://CONTROL_SET_MINUTE:
            minute += change;
            if (minute < 0) {
                minute = 59;
            }
            if (minute > 59) {
                minute = 0;
            }
            break;

        default:
            return 0;
    }

    RTCCOff();
    RTCCSetBinHour(hour);
    RTCCSetBinMin(minute);
    RTCCSetBinSec(0);
    RTCCSetBinDay(day);
    RTCCSetBinMonth(month);
    RTCCSetBinYear(year);
    RTCCCalculateWeekDay();
    RTCCSet(); // Copy the new values to the RTCC registers
    //UpdateDateTime();               // Update the display.

    return 1; // Call the default handler to show the button state.
}


