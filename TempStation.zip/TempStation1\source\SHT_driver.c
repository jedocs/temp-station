#include <math.h>  
//#include <p24Fxxxx.h>
#include "include\define.h"

typedef union {
    unsigned int i;
    float f;
} value;

enum {
    TEMP, HUMI
};

const unsigned int C1 = 400; // -4
const unsigned int C2 = 405; // 0.0405  (405 * 10^-4)
const unsigned short C3 = 28; // -2.8 * 10^-6  (28 * 10^-7)
const unsigned int D1 = 4000; // -40
const unsigned short D2 = 1; // 0.01

long int temp, k, SOt, SOrh, Ta_res, Rh_res;
//char Ta[16] = "Ta = 000.00    ";
//char Rh[16] = "Rh = 000.00    ";

char Ta[14] = "00.0C   00%";
//char Rh[9] = "Rh:00.0%";

extern char TxPacket[];

//**********************************************************************************
//*
//*		 writes a byte on the Sensibus and checks the acknowledge 
//*
//**********************************************************************************

char s_write_byte(unsigned char value)
 {
    unsigned char i, error = 0;

    SDA = 0;
    SDAdir = 0; // define SDA as output
    SCL = 0; // SCL low
    for (i = 0x80; i > 0; i /= 2) // repeat 8 times
    {
        if (i & value) SDA = 1; // if bit 7 = 1
        else SDA = 0;

        DelayMs(1); // 1us delay
        SCL = 1; // SCL high
        DelayMs(1); // 1us delay
        SCL = 0; // SCL low
    }

    DelayMs(1);
    SDAdir = 1; // define SDA as input
    SCL = 1; // SCL high
    DelayMs(1); // 1us delay
    error = SDA;
    SCL = 0; // 1us delay
    DelayMs(1); // 1us delay
    return error; //error=1 in case of no acknowledge
}

//**********************************************************************************
//*
//*		 reads a byte form the Sensibus and gives an acknowledge in case of "ack=1" 
//*
//**********************************************************************************

char s_read_byte(unsigned char ack)
 {
    unsigned char i, val = 0;
    for (i = 0x80; i > 0; i /= 2) //shift bit for masking
    {
        SCL = 1;
        DelayMs(1); //clk for SENSI-BUS
        if (SDA) val = (val | i); //read bit
        SCL = 0;
        DelayMs(1);
    }

    SDA = !ack;
    SDAdir = OUT;

    DelayMs(1); //in case of "ack==1" pull down DATA-Line
    SCL = 1; //clk #9 for ack
    DelayMs(1);
    SCL = 0;
    DelayMs(1);
    SDA = 1;
    SDAdir = IN; //release DATA-line
    return val;
}

//**********************************************************************************
//*
//*		generates a transmission start 
//*      		_____         ________
//*		DATA:        |_______|
//*           		___     ___
//* 	SCK : 	___|   |___|   |______
//*
//**********************************************************************************

void s_transstart(void)
 {
    SDA = 1;
    SDAdir = 1;
    DelayMs(1); // define SDA as input
    SCL = 1; // SCL high
    DelayMs(1); // 1us delay
    SDAdir = 0; // define SDA as output !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    SDA = 0; // SDA low!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    DelayMs(1); // 1us delay
    SCL = 0; // SCL low
    DelayMs(1); // 1us delay
    SCL = 1; // SCL high
    DelayMs(1); // 1us delay
    SDA = 1;
    SDAdir = 1; // define SDA as input
    DelayMs(1); // 1us delay
    SCL = 0; // SCL low
}

//**********************************************************************************
//*
//* communication reset: DATA-line=1 and at least 9 SCK cycles and trans start
//*       ____________________________________________________       _____
//* DATA:                                                     |_____| 
//*          _    _    _    _    _    _    _    _    _       ___    ___
//* SCK : __| |__| |__| |__| |__| |__| |__| |__| |__| |_____|   |__|   |___
//*
//**********************************************************************************

void s_connectionreset(void) {
    unsigned char i;
    TRISBbits.TRISB8 = 0;
    SDA = 1;
    TRISBbits.TRISB9 = 1;

    LATBbits.LATB8 = 0; // SCL low
    SDAdir = 1; // define SDA as input
    for (i = 1; i <= 18; i++) { // repeat 18 times
        if (LATBbits.LATB8) LATBbits.LATB8 = 0;
        else LATBbits.LATB8 = 1;
        DelayMs(1);
    } // invert SCL

    //	s_transstart();                   //transmission start????????????????????????????????????????????
}

//**********************************************************************************
//*
//* resets the sensor by a softreset 
//*
//**********************************************************************************
/*
char s_softreset(void)
{ 
        unsigned char error=0;
        s_connectionreset();              //reset communication
        error+=s_write_byte(RESET);       //send RESET-command to sensor
        return error;                     //error=1 in case of no response form the sensor
}

//**********************************************************************************
//*
//* reads the status register with checksum (8-bit)
//*
//**********************************************************************************

char s_read_statusreg(unsigned char *p_value, unsigned char *p_checksum)
{ 
        unsigned char error=0;
        s_transstart();                   //transmission start
        error=s_write_byte(STATUS_REG_R); //send command to sensor
 *p_value=s_read_byte(ACK);        //read status register (8-bit)
 *p_checksum=s_read_byte(noACK);   //read checksum (8-bit)
        return error;                     //error=1 in case of no response form the sensor
}

//**********************************************************************************
//*
//* writes the status register with checksum (8-bit)
//*
//**********************************************************************************

char s_write_statusreg(unsigned char *p_value)
{ 
        unsigned char error=0;
        s_transstart();                   //transmission start
        error+=s_write_byte(STATUS_REG_W);//send command to sensor
        error+=s_write_byte(*p_value);    //send value of status register
        return error;                     //error>=1 in case of no response form the sensor
}
 							   
//**********************************************************************************
//*
//* calculates temperature [�C] and humidity [%RH] 
//* input :  humi [Ticks] (12 bit) 
//*          temp [Ticks] (14 bit)
//* output:  humi [%RH]
//*          temp [�C]
//*
//**********************************************************************************
/*
void calc_sth11(float *p_humidity ,float *p_temperature)
{ 
        const float C1=-4.0;              // for 12 Bit
        const float C2=+0.0405;           // for 12 Bit
        const float C3=-0.0000028;        // for 12 Bit
        const float T1=+0.01;             // for 14 Bit @ 5V
        const float T2=+0.00008;           // for 14 Bit @ 5V

        float rh=*p_humidity;             // rh:      Humidity [Ticks] 12 Bit
        float t=*p_temperature;           // t:       Temperature [Ticks] 14 Bit
        float rh_lin;                     // rh_lin:  Humidity linear
        float rh_true;                    // rh_true: Temperature compensated humidity
        float t_C;                        // t_C   :  Temperature [�C]

        t_C=t*0.01 - 40;                  //calc. temperature from ticks to [�C]
        rh_lin=C3*rh*rh + C2*rh + C1;     //calc. humidity from ticks to [%RH]
        rh_true=(t_C-25)*(T1+T2*rh)+rh_lin;   //calc. temperature compensated humidity [%RH]
        if(rh_true>100)rh_true=100;       //cut if the value is outside of
        if(rh_true<0.1)rh_true=0.1;       //the physical possible range

 *p_temperature=t_C;               //return temperature [�C]
 *p_humidity=rh_true;              //return humidity[%RH]
}
 */
//********************************************************************
//*
//* calculates dew point
//* input:   humidity [%RH], temperature [�C]
//* output:  dew point [�C]
//*
//********************************************************************
/*
float calc_dewpoint(float h,float t)
{ 
        float logEx,dew_point;
        logEx=0.66077+7.5*t/(237.3+t)+(log10(h)-2);
        dew_point = (logEx - 0.66077)*237.3/(0.66077+7.5-logEx);
        return dew_point;
}
 */

//********************************************************************
//*
//* ftoa
//*
//********************************************************************

/*
void ftoa (float x, char *str)

{
        int ie, ij, k, ndig;
        double y;

        ndig = 2;

        // if x negative, write minus and reverse
        if ( x < 0)
        {
 *str++ = '-';
                x = -x;
        }

        // put x in range 1 <= x < 10
        if (x > 0.0) while (x < 1.0)
        {
                x =x* 10.0;
                ie--;
        }
        while (x >= 10.0)
        {
                x = x/10.0;
                ie++;
        }

        // in f format, number of digits is related to size
        ndig =+ ie;

        // round. x is between 1 and 10 and ndig will be printed to
        //right of decimal point so rounding is ...
        for (y = ij = 1; ij < ndig; ij++)
        y = y/10.;
        x =+ y/2.;
        if (x >= 10.0) {x = 1.0; ie++;} // repair rounding disasters
        // now loop.  put out a digit (obtain by multiplying by
  //	10, truncating, subtracting) until enough digits out 
        // if fstyle, and leading zeros, they go out special
        if (ie<0)
        {
 *str++ = '0'; *str++ = '.';
                if (ndig < 0) ie = ie-ndig; // limit zeros if underflow
                for (ij = -1; ij > ie; ij--)
 *str++ = '0';
        }
        for (ij=0; ij < ndig; ij++)
        {
                k = x;
 *str++ = k + '0';
                if (ij == ie) // where is decimal point
 *str++ = '.';
                x =- (y=k);
                x =x* 10.0;
        }
 *str = '\0';
}
 */
//**********************************************************************************
//*
//* makes a measurement (humidity/temperature) with checksum
//*
//**********************************************************************************

char s_measure(unsigned char *p_value, unsigned char *p_checksum, unsigned char mode)
 {
    unsigned error = 0;
    unsigned int i;
    unsigned char a, b, c, sbuf[6];


    s_transstart(); //transmission start
    DelayMs(1);

    switch (mode) { //send command to sensor
        case TEMP: error += s_write_byte(MEASURE_TEMP);
            break;
        case HUMI: error += s_write_byte(MEASURE_HUMI);
            break;
        default: break;
    }

    DelayMs(10);
    for (i = 0; i < 65535; i++) if (SDA == 0) break; //wait until sensor has finished the measurement
    if (SDA == 1) error += 1; // or timeout (~2 sec.) is reached

    //*(p_value)  =s_read_byte(ACK);    //read the first byte (MSB)
    //	*(p_value+1)=s_read_byte(ACK);    //read the second byte (LSB)
    //*p_checksum =s_read_byte(noACK);  //read checksum

    a = s_read_byte(ACK);
    b = s_read_byte(noACK); //read the second byte (LSB)
    //	c = s_read_byte(noACK);  //read checksum




    switch (mode) {
        case TEMP: SOt = a * 256 + b; // function for measuring (command 0x05 is for humidity)
            // Calculating temperature
            // Ta_res = D1 + D2 * SOt
            if (SOt > D1) // if temperature is positive
                Ta_res = SOt * D2 - D1; // calculate temperature
            else // else (if temperature is negative)
                Ta_res = D1 - SOt * D2; // calculate temperature
            break;
        case HUMI: SOrh = a * 256 + b;
            // Calculating humidity
            // Rh_res = C1 + C2 * SOrh + C3 * SOrh^2
            temp = SOrh * SOrh * C3 / 100000; // calculate humidity
            Rh_res = SOrh * C2 / 100 - temp - C1;
            break;
        default: break;
    }
    /*
    // Preparing temperature for LCD
        Ta[5] = Ta_res / 10000 + 48;                  // example: Ta[5] = 12345 / 10000 = 1, 1 + 48 = '1' - ASCII
        Ta[6] = Ta_res % 10000 / 1000 + 48;           // example: Ta[6] = 12345 % 10000 = 2345, Ta[6] = 2345 / 1000 = 2, 2 + 48 = '2' - ASCII
        Ta[7] = Ta_res % 1000 / 100 + 48;             // example: Ta[7] = 12345 % 1000 = 345, Ta[7] = 345 / 100 = 3, 3 + 48 = '3' - ASCII
        Ta[9] = Ta_res % 100 / 10 + 48;               // example: Ta[9] = 12345 % 100 = 45, Ta[9] = 45 / 10 = 4, 4 + 48 = '4' - ASCII
        Ta[10] = Ta_res % 10 + 48;                    // example: Ta[10] = 12345 % 10 = 5, 5 + 48 = '5' - ASCII

    // Preparing humidity for LCD
        Rh[5] = Rh_res / 10000 + 48;                  // example: Rh[5] = 12345 / 10000 = 1, 1 + 48 = '1' - ASCII
        Rh[6] = Rh_res % 10000 / 1000 + 48;           // example: Rh[6] = 12345 % 10000 = 2345, Rh[6] = 2345 / 1000 = 2, 2 + 48 = '2' - ASCII
        Rh[7] = Rh_res % 1000 / 100 + 48;             // example: Rh[7] = 12345 % 1000 = 345, Rh[7] = 345 / 100 = 3, 3 + 48 = '3' - ASCII
        Rh[9] = Rh_res % 100 / 10 + 48;               // example: Rh[9] = 12345 % 100 = 45, Rh[9] = 45 / 10 = 4, 4 + 48 = '4' - ASCII
        Rh[10] = Rh_res % 10 + 48;                    // example: Rh[10] = 12345 % 10 = 5, 5 + 48 = '5' - ASCII

    // delete unnecessary digits (zeros)
        if (Ta[5] == '0')                             // if Ta[5] = '0' then
          Ta[5] = ' ';                                // insert blank character to Ta[5]
        if (Ta[5] == ' ' && Ta[6] == '0')             // if Ta[5] is blank and Ta[6] = '0' then
          Ta[6] = ' ';                                // insert blank character to Ta[6]

        if (Rh[5] == '0')                             // if Ta[5] = '0' then
          Rh[5] = ' ';                                // insert blank character to Ta[5]
        if (Rh[5] == ' ' && Rh[6] == '0')             // if Ta[5] is blank and Ta[6] = '0' then
          Rh[6] = ' ';                                // insert blank character to Ta[6]
    // Display temperature on LCD

     */


    // Preparing temperature for LCD
    //Ta[1] = Ta_res / 10000 + 48;                  // example: Ta[5] = 12345 / 10000 = 1, 1 + 48 = '1' - ASCII
    //  Ta[0] = Ta_res % 10000 / 1000 + 48;           // example: Ta[6] = 12345 % 10000 = 2345, Ta[6] = 2345 / 1000 = 2, 2 + 48 = '2' - ASCII
    //Ta[1] = Ta_res % 1000 / 100 + 48;             // example: Ta[7] = 12345 % 1000 = 345, Ta[7] = 345 / 100 = 3, 3 + 48 = '3' - ASCII
    // Ta[3] = Ta_res % 100 / 10 + 48;               // example: Ta[9] = 12345 % 100 = 45, Ta[9] = 45 / 10 = 4, 4 + 48 = '4' - ASCII
    //Ta[8] = Ta_res % 10 + 48;                    // example: Ta[10] = 12345 % 10 = 5, 5 + 48 = '5' - ASCII

    // Preparing humidity for LCD
    // Ta[2] = Rh_res / 10000 + 48;                  // example: Rh[5] = 12345 / 10000 = 1, 1 + 48 = '1' - ASCII
    //    Ta[9] = Rh_res % 10000 / 1000 + 48;           // example: Rh[6] = 12345 % 10000 = 2345, Rh[6] = 2345 / 1000 = 2, 2 + 48 = '2' - ASCII
    //  Ta[10] = Rh_res % 1000 / 100 + 48;             // example: Rh[7] = 12345 % 1000 = 345, Rh[7] = 345 / 100 = 3, 3 + 48 = '3' - ASCII
    //    Ta[11] = Rh_res % 100 / 10 + 48;               // example: Rh[9] = 12345 % 100 = 45, Rh[9] = 45 / 10 = 4, 4 + 48 = '4' - ASCII
    //Rh[8] = Rh_res % 10 + 48;                    // example: Rh[10] = 12345 % 10 = 5, 5 + 48 = '5' - ASCII

    // delete unnecessary digits (zeros) !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!44
    // if (Ta[3] == '0')                             // if Ta[5] = '0' then
    // Ta[3] = ' ';                                // insert blank character to Ta[5]
    // if (Ta[3] == ' ' && Ta[4] == '0')             // if Ta[5] is blank and Ta[6] = '0' then
    // Ta[4] = ' ';                                // insert blank character to Ta[6]

    //    if (Rh[3] == '0')                             // if Ta[5] = '0' then
    //    Rh[3] = ' ';                                // insert blank character to Ta[5]
    // if (Rh[3] == ' ' && Rh[4] == '0')             // if Ta[5] is blank and Ta[6] = '0' then
    // Rh[4] = ' ';                                // insert blank character to Ta[6]
    // Display temperature on LCD


    Ta[0] = Ta_res % 10000 / 1000 + 48; // example: Ta[6] = 12345 % 10000 = 2345, Ta[6] = 2345 / 1000 = 2, 2 + 48 = '2' - ASCII
    Ta[1] = Ta_res % 1000 / 100 + 48; // example: Ta[7] = 12345 % 1000 = 345, Ta[7] = 345 / 100 = 3, 3 + 48 = '3' - ASCII
    Ta[3] = Ta_res % 100 / 10 + 48; // example: Ta[9] = 12345 % 100 = 45, Ta[9] = 45 / 10 = 4, 4 + 48 = '4' - ASCII

    Ta[8] = Rh_res % 10000 / 1000 + 48; // example: Rh[6] = 12345 % 10000 = 2345, Rh[6] = 2345 / 1000 = 2, 2 + 48 = '2' - ASCII
    Ta[9] = Rh_res % 1000 / 100 + 48; // example: Rh[7] = 12345 % 1000 = 345, Rh[7] = 345 / 100 = 3, 3 + 48 = '3' - ASCII


    TxPacket[5] = (((Ta[0] - 48) << 4)+(Ta[1] - 48)); //TxPacket[8] = Ta[0];
    TxPacket[6] = Ta[3] - 48; //TxPacket[9] = Ta[1];
    TxPacket[7] = (((Ta[8] - 48) << 4)+(Ta[9] - 48)); //TxPacket[10] = Ta[2];
    TxPacket[11] = Ta[3];

    TxPacket[13] = Ta[8];
    TxPacket[14] = Ta[9];


    ClearDevice();
    OutTextXY(3, 41, Ta);
    //		OutTextXY(0,30, Rh);
    //		TransferToLCD();
    // display humidity on second row, i column
    //DelayMs(500); 
    return error;
}

//**********************************************************************************
//*
//* measure
//*
//**********************************************************************************

void measure() {
    value humi_val, temp_val;
    //  	float dew_point;
    unsigned char error, checksum;
    unsigned int i;
    //	char sbuf[30];

    I2C1CONbits.I2CEN = 0;
    ODCBbits.ODB8 = 1;
    ODCBbits.ODB9 = 1;
    SCLdir = 0;

    //	s_connectionreset();

    //  	while(1)
    //	{
    //
    s_connectionreset();

    error = 0;
    error += s_measure((unsigned char*) &humi_val.i, &checksum, HUMI); //measure humidity
    error += s_measure((unsigned char*) &temp_val.i, &checksum, TEMP); //measure temperature
    //	DelayMs(200);                       
    //}
}



