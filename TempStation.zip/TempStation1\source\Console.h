
#include "GenericTypeDefs.h"
//#include "compiler.h"
//#include "RadioDriverDefs.h"
#define ROM const

	//This case is for PIC24 and processors working with Explorer 16 board
        void ConsoleInit(void);
        #define ConsoleIsPutReady()     (U2STAbits.TRMT)
        void ConsolePut(BYTE c);
        void ConsolePutROMString(ROM char* str);
    
        #define ConsoleIsGetReady()     (IFS1bits.U2RXIF)
        BYTE ConsoleGet(void);
        BYTE ConsoleInput(void);
        void PrintChar(BYTE);
        void PrintDigit(BYTE toPrint);
	
	void PrintDigitW(WORD toPrint);
	#define nl() ConsolePutROMString((ROM char*)"\r\n");
	#define c(a) ConsolePutROMString((ROM char*)a);

