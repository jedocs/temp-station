#include "include\define.h"

unsigned char VMap[1024];

/*********************************************************************
* Function:  void ResetDevice()
********************************************************************/
void ResetDevice(void)
{
    unsigned int x,y;

   	RST_LAT_BIT = 1;
	DelayMs(2);

	A0_LAT_BIT = 0;
	CS_LAT_BIT = 0;

	SPIPut(0x40);	//(2) Display start line set 0 0 1 0 0 0 0 0 0 $40 Display start line 0
	SPIPut(0xA0);	//(8) ADC set 0 1 0 1 0 0 0 0 0 $A0 ADC normal
	SPIPut(0xC8);	//(15) Common output mode select 0 1 1 0 0 1 0 0 0 $C8 reverse COM63~COM0
	SPIPut(0xA6);	//(9) Display normal/reverse 0 1 0 1 0 0 1 1 0 $A6 Display normal
	SPIPut(0xA2);	//(11) LCD bias set 0 1 0 1 0 0 0 1 0 $A2 Set bias 1/9 (Duty 1/65)
	SPIPut(0x2F);	//(16) Power control set 0 0 0 1 0 1 1 1 1 $2F Booster, Regulator and Follower on
	SPIPut(0xF8);	//(20) Booster ratio set 0 1 1 1 1 1 0 0 0 $F8 Set internal Booster to 4x
	SPIPut(0x00);	//0 0 0 0 0 0 0 0 $00
	SPIPut(0x27);	//(17) V0 voltage regulator set 0 0 0 1 0 0 1 1 1 $27 
	SPIPut(0x81);	//(18) Electronic volume mode set 0 1 0 0 0 0 0 0 1 $81 Contrast set
	SPIPut(0x10);	//0 0 0 1 0 1 1 0 $10
	SPIPut(0xAC);	//(19) Static indicator set 0 1 0 1 0 1 1 0 0 $AC No indicator
	SPIPut(0x00);	//0 0 0 0 0 0 0 0 $00
	SPIPut(0xAF);	//(1) Display ON/OFF 0 1 0 1 0 1 1 1 1 $AF Display on

        
        //a5: all pixels on, a7:reverse display, a6:normal display
	
	CS_LAT_BIT = 1;
 }

//*********************************************************
void ClearDevice(void)
{
	int i;
	for (i=0;i<1024;i++) VMap[i]=0x00;
}

//**********************************************************

void TransferToLCD(void)

{
unsigned char y,x;

	CS_LAT_BIT = 0;

	for (y=0;y<8;y++)
	{
		A0_LAT_BIT = 0;
		SPIPut(0xB0+y);	// set bank
		SPIPut(0x10);	//set column	
		SPIPut(0x04);	//set column 4
		A0_LAT_BIT = 1;

		for (x=0;x<128;x++)
		{
			SPIPut(VMap[(y<<7)+x]);
		}
	}

	CS_LAT_BIT = 1;
}

/*********************************************************************
* Function: void PutPixel(signed short int x, signed short int y)
*
********************************************************************/
void PutPixel(unsigned short int x, unsigned short int y)
{
	VMap[((y>>3)<<7)+x] |= (1<<(y&7)); 
}

/*********************************************************************
* Function: WORD GetPixel(signed short int x, signed short int y)
*
********************************************************************/
unsigned char GetPixel(signed short int x, signed short int y)
{
    return (VMap[((y>>3)<<7)+x] & (1<<(y&7)));
}
